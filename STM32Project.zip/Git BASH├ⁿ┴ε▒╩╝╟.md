# Git BASH命令笔记
创建一个以日期命名的文件  
```
touch `date +%Y-%m-%d`.c
```
其中的``内是bash的命令，直接把date +%Y-%m-%d打在命令行里面就能输出YYYY-MM-DD的日期，这行命令生成一个YYYY-MM-DD.c的c文件。